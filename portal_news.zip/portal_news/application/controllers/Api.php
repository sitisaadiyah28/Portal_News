<?php
	
	defined('BASEPATH') OR exit ('No Script Direct');

	class Api extends CI_Controller{

		function __construct(){
			parent::__construct();
			date_default_timezone_set('Asia/Jakarta');
			error_reporting(E_ALL);
			ini_set('Display Error', 1);
		}

		//API REGISTER USER
		function registerUser(){
			$namaUser = $this->input->post('nama_user');
			$email = $this->input->post('email');
			$telp = $this->input->post('notelp');
			$password = $this->input->post('password');

			$this->db->where('email', $email);
			$q = $this->db->get('tb_user');

			if($q -> num_rows() > 0){
				$data['status'] = 404;
				$data['message'] ="Email telah terdaftar";
			} else{
				$save['nama_user'] = $namaUser;
				$save['email'] = $email;
				$save['notelp'] = $telp;
				$save['password'] = md5($password);

				$querySaved = $this->db->insert('tb_user', $save);

				if($querySaved){
					$data['status'] = 200;
					$data['message'] ="Successfully Register";
				} else{
					$data['status'] = 404;
					$data['message'] ="Failed Register";
				}
			}
			echo json_encode($data);
			//Decode : dari Json ke Object
			//enCode : object ke Json

		}

		function loginUser(){
			$email = $this->input->post('email');
			$password = $this->input->post('password');

			$this->db->where('email', $email);
			$this->db->where('password', md5($password));

			$q = $this->db->get('tb_user');

			if($q -> num_rows() > 0){
				$data['status'] = 200; // untuk isian status mah terserah aja
				$data['message'] ="Successfully Login User";
				$data['user'] = $q -> result();
			}else{
				$data['status'] = 404;
				$data['message'] = "Failed Login User";
			}
			echo json_encode($data);
		}

		//API GET DATA KATEGORI BERITA
		function getKategori(){

            $query = $this->db->get('tb_kategori');

            if ($query -> num_rows() > 0) {
                //$data['data'] = $q -> result();
                $data['status'] = 200; 
                $data['message'] = "success";
                $data['kategori'] = $query->result();
            } else {
                $data['status'] = 404;
                $data['message'] = "error";
            }

            echo json_encode($data);
        }

        //API ADD BERITA
        function addBerita(){
			$judul = $this->input->post('judul');
			$deskripsi = $this->input->post('deskripsi');
			$idKategori = $this->input->post('id_kategori');
			$idUser = $this->input->post('iduser');
			$config['upload_path'] = './images/'; // tipe string dan file
			$config['allowed_types'] = 'gif|jpg|png|jpeg';

			$this->load->library('upload', $config); // ini proses untuk memasukkan ke dalam libraries

			if(! $this->upload->do_upload('image')){
				$error = array('error' => $this->upload->display_errors());
				$data1 = array(
					'message' => $error,
					'status' => 404,
				);
			}else{
				$data = array('upload_data' => $this->upload->data()); //proses upload
				$save['judul_berita'] = $judul;
				$save['deskripsi'] = $deskripsi;
				$save['created_at'] = date('Y-m-d H:i:s');
				$save['id_user'] = $idUser;
				$save['id_kategori'] = $idKategori;
				$save['images_berita'] = $data['upload_data']['file_name']; //ini proses untuk menyimpan ke databasenya
				$query = $this->db->insert('tb_berita', $save);

				//Output Request
				$data1 = array(
					'message' => "Successfully Upload News",
					'status' => 200,
					'data' => $data['upload_data']['file_name'],
				);
			}
			echo json_encode($data1);
		}

        //API get Berita
        function getBerita(){
			$idUser = $this->input->post('iduser');
			$this->db->where('tb_berita.id_user', $idUser);
			$this->db->order_by('tb_berita.created_at', 'DESC');
			$this->db->join('tb_kategori','tb_kategori.id_kategori = tb_berita.id_kategori');
			$this->db->join('tb_user','tb_user.id_user = tb_berita.id_user');
   		 	$query = $this->db->get('tb_berita');
			//$query = $this->db->get('tb_news');
			if($idUser != null || $idUser != ""){
				if($query -> num_rows() > 0){
					$data['message'] = "Successfully Get Data Berita With Id User";
					$data['status'] = 200;
					$data['berita'] = $query->result();
				}else{
					$data['message'] = "Failed Get Data Kaba Nagari";
					$data['status'] = 400;
				}
			} else {
				$this->db->join('tb_kategori','tb_kategori.id_kategori = tb_berita.id_kategori');
				$this->db->join('tb_user','tb_user.id_user = tb_berita.id_user');
				$this->db->order_by('created_at', 'DESC');
				 $q = $this->db->get('tb_berita');
				 if($q -> num_rows() > 0){
					$data['message'] = "Successfully Get Data Berita Without Id User";
					$data['status'] = 200;
					$data['berita'] = $q->result();
				}else{
					$data['message'] = "Failed Get Data Kaba Nagari";
					$data['status'] = 400;
				}

			}
			echo json_encode($data);
		}

		function getBeritaByIdKategori(){
			$idkategori = $this->input->post('id_kategori');
			
			$this->db->order_by('created_at', 'DESC');

   		 	$this->db->select("*");
			$this->db->from("tb_berita");
			$this->db->where("tb_berita.id_kategori", $idkategori);
			$this->db->join('tb_kategori','tb_kategori.id_kategori = tb_berita.id_kategori');
			$this->db->join('tb_user','tb_user.id_user = tb_berita.id_user');
		
			$query = $this->db->get();
			if($query -> num_rows() > 0){
					$data['message'] = "Successfully Get Data Kaba Nagari";
					$data['status'] = 200;
					$data['beritakategori'] = $query->result();
			}else{
					$data['message'] = "Failed Get Data Kaba Nagari";
					$data['status'] = 400;
			}
			
			echo json_encode($data);
		}

		//API delete Berita
		function deleteBerita(){
			$idBerita = $this->input->post('idberita');
			$this->db->where('id_berita', $idBerita);

			$status = $this->db->delete('tb_berita');
			if ($status == true){
				$data['message'] = "Successfully delete kaba nagari";
				$data['status'] = 200;
			}else {
				$data['message'] = "Failed delete kaba nagari";
				$data['status'] = 404;
			}
			echo json_encode($data);
		}

		function updateBerita(){
			$idBerita = $this->input->post('idBerita');
			$judul = $this->input->post('judul');
			$deskripsi = $this->input->post('deskripsi');
			$idKategori = $this->input->post('idkategori');
			$config['upload_path'] = './images/';
			$config['allowed_types'] = 'gif|jpg|png|jpeg';

			$this->load->library('upload', $config);
			$this->db->where('id_berita', $idBerita);


			if(! $this->upload->do_upload('image')){
				$save['judul_berita'] = $judul;
				$save['deskripsi'] = $deskripsi;
				$save['id_kategori'] = $idKategori;
				$save['created_at'] = date('Y-m-d H:i:s');
				$query = $this->db->update('tb_berita', $save);
				$data1 = array(
					'message' => "Successfully Upload Berita Without Image",
					'status' => 200,
				);
			} else {
				// Upload to folder
				$data = array('upload_data' => $this->upload->data());  

				// Upload to database
				$save['judul_berita'] = $judul;
				$save['deskripsi'] = $deskripsi;
				$save['created_at'] = date('Y-m-d H:i:s');
				$save['images_berita'] = $data['upload_data']['file_name'];
				$query = $this->db->update('tb_berita', $save);

				// Ouput Request
				$data1 = array(
					'message' => "Successfully Upload Berita",
					'status' => 200,
					'data' => $data['upload_data']['file_name'],
				);

			}

			echo json_encode($data1);

		}

	}

?